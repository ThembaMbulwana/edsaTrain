# edsaTrain
This library was created for the 'Let's Build a Python Package' edsa exercise.

# Building this package locally
'python setup.py sdist'

# installing this package from GitHub
'pip install git + '